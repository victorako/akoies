# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import DataMigration
from django.db import models

class Migration(DataMigration):

    def forwards(self, orm):
        # TicketView
        orm.TextBlock.objects.create(category="homeview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        orm.TextBlock.objects.create(category="kidsview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        orm.TextBlock.objects.create(category="parentsview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        orm.TextBlock.objects.create(category="contestview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        orm.TextBlock.objects.create(category="contestformview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        orm.TextBlock.objects.create(category="orderhomeview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")        

        orm.TextBlock.objects.create(category="faqview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        orm.TextBlock.objects.create(category="orderpremiumview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")
        
        orm.TextBlock.objects.create(category="orderfamilyview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        orm.TextBlock.objects.create(category="schoolsview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        orm.TextBlock.objects.create(category="schoolsquoteview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        orm.TextBlock.objects.create(category="ticketview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        orm.TextBlock.objects.create(category="page-trial", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")


    def backwards(self, orm):
        "Write your backwards methods here."

    models = {
        'textblock.textblock': {
            'Meta': {'ordering': "('category',)", 'unique_together': "(('category', 'slug'),)", 'object_name': 'TextBlock'},
            'category': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '80'}),
            'text': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'})
        }
    }

    complete_apps = ['textblock']
    symmetrical = True
