# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import DataMigration
from django.db import models

class Migration(DataMigration):

    def forwards(self, orm):
        # TicketView
        orm.TextBlock.objects.create(category="ticketview", slug="waar-kunnen-we-u-mee-helpen",
                                     title="Waar kunnen we u mee helpen?",
                                     text="Opmerkingen, vragen of suggesties over de cursus kunt u hieronder kwijt. Onze klantenservice is op werkdagen geopend van 09:00 - 17:00. <span>Tel. 088 5500145</span>")
        orm.TextBlock.objects.create(category="ticketview", slug="parents-opinion",
                                     title="Annemieke Bitterling",
                                     text="“DuckTypen vinden wij goed. Onze dochter heeft telkens zin om aan de cursus te beginnen en wij zien haar vorderingen duidelijk.”")
        orm.TextBlock.objects.create(category="ticketview", slug="korting",
                                     title="Ontvang 20% korting op een 2e cursus!",
                                     text="Bestelt u twee cursussen, dan ontvangt u altijd 20% korting op de 2e typecursus.")

    def backwards(self, orm):
        "Write your backwards methods here."

    models = {
        'textblock.textblock': {
            'Meta': {'ordering': "('category',)", 'unique_together': "(('category', 'slug'),)", 'object_name': 'TextBlock'},
            'category': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '80'}),
            'text': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'})
        }
    }

    complete_apps = ['textblock']
    symmetrical = True
