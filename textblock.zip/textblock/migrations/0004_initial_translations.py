# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import DataMigration
from django.db import models

class Migration(DataMigration):

    def forwards(self, orm):
        orm.TextBlock.objects.all().delete()

        # HomeView
        orm.TextBlock.objects.create(category="homeview", slug="vrolijkste-typecursus",
                                     title="De vrolijkste typecursus van Nederland!",
                                     text="De typecursus waarmee je blind leert typen als verslaggever van de Duckstadkrant.")
        orm.TextBlock.objects.create(category="homeview", slug="leren-typen",
                                     title="Leren typen door het<br>spelen van games",
                                     text="Verschillende leuke games, afgewisseld met leeroefeningen. Zo blijft de cursus leuk.")
        orm.TextBlock.objects.create(category="homeview", slug="volledig-online",
                                     title="Volledig online dus<br>overal en altijd spelen",
                                     text="De typecursus waarmee je blind leert typen als verslaggever van de Duckstadkrant.")
        orm.TextBlock.objects.create(category="homeview", slug="cursus-gehaald",
                                     title="Cursus gehaald?<br>Ontvang een diploma!",
                                     text="Je hebt een jaar de tijd om de cursus succesvol af te ronden. Gelukt? Dan krijg je een eigen typediploma!")
        orm.TextBlock.objects.create(category="homeview", slug="wat-is-ducktypen",
                                     title="Wat is DuckTypen? Bekijk het filmpje",
                                     text="In dit filmpje leggen we uit waarom blind leren typen belangrijk is en nemen we je mee door de DuckTypen typecursus.")
        orm.TextBlock.objects.create(category="homeview", slug="waarom-blind-typen",
                                     title="Waarom blind typen?",
                                     text="Blind kunnen typen heeft vele voordelen. Dit zijn er al vier:")
        orm.TextBlock.objects.create(category="homeview", slug="sneller-werken",
                                     title="Sneller werken",
                                     text="Blind typen met<br>120 aanslagen per minuut")
        orm.TextBlock.objects.create(category="homeview", slug="efficienter-werken",
                                     title="Efficiënter werken",
                                     text="Betere concentratie op<br>de inhoud van je werk")
        orm.TextBlock.objects.create(category="homeview", slug="goede-houding",
                                     title="Een goede houding",
                                     text="Je kijkt niet naar je toetsenbord,<br>dus beter voor je rug!")
        orm.TextBlock.objects.create(category="homeview", slug="tijd-overhouden",
                                     title="Tijd overhouden",
                                     text="Eerder klaar met je huiswerk,<br>dus meer tijd voor ontspanning")
        orm.TextBlock.objects.create(category="homeview", slug="educatie-en-fun",
                                     title="Educatie en Fun. Bestel hier de cursus",
                                     text="In de cursus werkt je kind mee als verslaggever van de Duckstadkrant. Games gecombineerd met leeroefeningen zorgen dat de typecursus tot het einde leuk blijft.")
        orm.TextBlock.objects.create(category="homeview", slug="opinion",
                                     title="FRANK WESTHOF",
                                     text='"Mijn zoon vindt de cursus erg leuk. Hij wordt door de spellen getriggerd om zelf te gaan oefenen. En ondertussen leert hij typen. Een goede aanschaf!"')
        orm.TextBlock.objects.create(category="homeview", slug="korting",
                                     title="Ontvang 20% korting op een 2e cursus!",
                                     text="Bestelt u twee cursussen, dan ontvangt u altijd 20% korting op de 2e typecursus.")

        # KidsView
        orm.TextBlock.objects.create(category="kidsview", slug="reporter-van-de-duckstadkrant",
                                     title="Jij bent de reporter van de Duckstadkrant",
                                     text="In Duckstad is altijd iets te beleven en natuurlijk zit jij overal met je snavel bovenop! Je beleeft de spannendste avonturen én je leert razendsnel typen!")
        orm.TextBlock.objects.create(category="kidsview", slug="bekijk-het-filmpje",
                                     title="Bekijk het filmpje",
                                     text="Welkom in Duckstad! Zo ziet de cursus eruit.")
        orm.TextBlock.objects.create(category="kidsview", slug="speel-games",
                                     title="Speel games en breng verslag uit over je avonturen!",
                                     text="Je speelt verschillende games en schrijft daarna artikelen voor de Duckstadkrant.")
        orm.TextBlock.objects.create(category="kidsview", slug="leukste-avonturen",
                                     title="Beleef de leukste avonturen met al je favoriete Duckstad figuren.",
                                     text="Je speelt verschillende games en schrijft daarna artikelen voor de Duckstadkrant.")
        orm.TextBlock.objects.create(category="kidsview", slug="verschillende-avonturen",
                                     title="Beleef 15 verschillende avonturen!",
                                     text="Dit zijn drie van de 15 avonturen die je gaat spelen.")
        orm.TextBlock.objects.create(category="kidsview", slug="help-oom-dagobert",
                                     title="Help oom Dagobert een schat te vinden",
                                     text="")
        orm.TextBlock.objects.create(category="kidsview", slug="ga-koopjes",
                                     title="Ga koopjes jagen met Katrien",
                                     text="")
        orm.TextBlock.objects.create(category="kidsview", slug="help-bolderbast",
                                     title="Help Bolderbast in zijn nieuwe broodjeszaak",
                                     text="")
        orm.TextBlock.objects.create(category="kidsview", slug="beste-reporter",
                                     title="Word de beste reporter van Duckstad!",
                                     text="Speel een gratis proefspel als verslaggever van de Duckstadkrant.")
        # FaqView
        orm.TextBlock.objects.create(category="faqview", slug="faq-header",
                                     title="Komt u er niet uit?",
                                     text="")
        orm.TextBlock.objects.create(category="faqview", slug="faq-sidebar",
                                     title="Staat uw vraag er niet tussen?",
                                     text="Onze klantenservice staat op werkdagen tussen 9.00 en 17.00 uur voor u klaar.")

        orm.TextBlock.objects.create(category="faqview", slug="tab-1-1",
                                     title="Wat is Ducktypen?",
                                     text="Ducktypen is een online typecursus voor op de computer. Overal waar een internetverbinding is, kan uw zoon of dochter inloggen en de cursus volgen. Dus ook op de naschoolse opvang of tijdens een logeerpartijtje.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-1-2",
                                     title="Behaal ik een diploma na het succesvol afronden van de cursus?",
                                     text="Ja, als de cursus is afgerond, krijgt uw zoon of dochter een digitaal diploma met zijn of haar naam erop, ondertekend door oom Donald. Dit diploma kunt u zelf printen.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-1-3",
                                     title="Hoe lang kan ik gebruik maken van Ducktypen?",
                                     text="Het account is na registreren één jaar geldig.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-1-4",
                                     title="Hoe lang doet mijn zoon of dochter over de typecursus?",
                                     text="We adviseren om 5 keer per week een half uurtje te typen. Dan bouwt de cursist een goede vaardigheid op en blijft het geleerde goed hangen. Bij een gemiddeld niveau doen cursisten ongeveer 5-6 maanden over DuckTypen.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-1-5",
                                     title="Wordt mijn kind gedurende de cursus begeleid?",
                                     text="In de cursus is een virtuele mentor ingebouwd: meester Warbol. Hij legt duidelijk uit wat uw zoon of dochter moet doen.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-1-6",
                                     title="Hoe kan ik de voortgang van mijn kind volgen?",
                                     text="Elke ouder heeft een ouderdashboard. Hier kunt u de voortgang van uw kind volgen en motiverende berichtjes sturen.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-1-7",
                                     title="Is DuckTypen geschikt voor dyslectici?",
                                     text="Als uw kind dyslectisch is raden wij aan om eerst de proefles te spelen. Er zijn kinderen met dyslexie die de cursus spelen. Omdat DuckTypen nog geen speciale dyslexie versie heeft, geven wij geld terug als blijkt dat de cursus toch te moeilijk is voor uw zoon/ dochter.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-1-8",
                                     title="Is het mogelijk extra oefeningen te doen?",
                                     text="Alle levels die uw kind succesvol heeft gehaald, kunnen opnieuw worden gespeeld.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-1-9",
                                     title="Uit hoeveel lessen bestaat de cursus?",
                                     text="De cursus is opgebouwd uit zes kranten die de cursist moet maken. Elke krant bestaat weer uit vijf verschillende artikelen die opgebouwd zijn uit een game en een leeroefening. Na de zesde krant is de cursus afgerond.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-1-10",
                                     title="Wat gebeurt er als ik midden in een oefening stop?",
                                     text="De cursus houdt bij waar uw kind zich bevindt. Het is dus mogelijk op elk gewenst moment te stoppen. Als er opnieuw wordt ingelogd, gaat de cursus op hetzelfde punt verder.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-1-11",
                                     title="Voor welke leeftijd is DuckTypen geschikt?",
                                     text='DuckTypen wordt gespeeld door kinderen vanaf 7 jaar en kan in principe door iedereen (ook volwassenen) gevolgd worden. Wilt u weten of DuckTypen geschikt is voor uw zoon of dochter? Speel dan <a href="/gratis-proefles/">hier</a> een gratis proefles.')

        orm.TextBlock.objects.create(category="faqview", slug="tab-2-1",
                                     title="Hoe bestel ik Ducktypen?",
                                     text="Ga naar prijzen en druk op de knop ‘Cursus bestellen’. Vul alle gegevens in en rond de betaling af. Nu kunt u samen met uw kind een account aanmaken en meteen starten met de cursus.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-2-2",
                                     title="Kan ik korting krijgen?",
                                     text="Als Donald Duck abonnee krijgt u standaard maar liefst 25% extra korting op de online typecursus Ducktypen. De speciale kortingscode vindt u in het Clubhuis op Donaldduck.nl. Tijdens speciale acties kan de korting veranderen.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-2-3",
                                     title="Hoe kan ik betalen?",
                                     text="Via iDeal is het mogelijk het bedrag in één keer over te maken. Zo heeft u direct toegang tot de cursus. Het is niet mogelijk in termijnen te betalen.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-2-4",
                                     title="Hoe lang kan ik gebruik maken van Ducktypen?",
                                     text="Het account is na registreren één jaar geldig.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-2-5",
                                     title="Ik heb mijn inloggegevens voor Ducktypen nog niet ontvangen, maar ik heb al wel betaald. Kan ik deze gegevens alsnog ontvangen?",
                                     text="Als het goed is, heeft u zich tijdens de bestelling geregistreerd en heeft u uw inloggegevens ontvangen. Log met deze gegevens in bij inloggen. Daar kunt u uw kind registreren.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-2-6",
                                     title="Is het mogelijk meerdere accounts aan te maken?",
                                     text="Ja, dat is mogelijk. Wanneer u zich voor het eerst registreert en een typecursus afneemt, kunt u daarna als ouder inloggen en nog een cursus bestellen. Deze wordt dan direct aan uw bestaande account toegevoegd.")

        orm.TextBlock.objects.create(category="faqview", slug="tab-3-1",
                                     title="Ik heb mijn inloggegevens voor Ducktypen nog niet ontvangen, maar ik heb al wel betaald. Kan ik deze gegevens alsnog ontvangen?",
                                     text="Als het goed is, heeft u zich tijdens de bestelling geregistreerd en heeft u uw inloggegevens ontvangen. Log met deze gegevens in bij inloggen. Daar kunt u uw kind registreren.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-3-2",
                                     title="Is het mogelijk meerdere accounts aan te maken?",
                                     text="Ja, dat is mogelijk. Wanneer u zich voor het eerst registreert en een typecursus afneemt, kunt u daarna als ouder inloggen en nog een cursus bestellen. Deze wordt dan direct aan uw bestaande account toegevoegd.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-3-3",
                                     title="Kan iemand anders ook meedoen op mijn account?",
                                     text="Nee. De typecursus volgt een leercurve en houdt bij waar en op welk niveau uw kind zich bevindt.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-3-4",
                                     title="Tijdens het spelen pauzeert de oefening",
                                     text="DuckTypen is gebouwd in Flash. Als de cursist met de muis buiten de Flash omgeving klikt, dan pauzeert het spel. U kunt verder gaan door weer in de Flash omgeving te klikken.")
        orm.TextBlock.objects.create(category="faqview", slug="tab-3-5",
                                     title="Wachtwoord vergeten/wijzigen",
                                     text="Ouders kunnen ook inloggen en via het ouderdashboard het wachtwoord van de cursist aanpassen. Kunt u niet inloggen? Klik dan op ‘Wachtwoord vergeten’. Per mail ontvangt u een nieuw wachtwoord. ")

        # ParentsView
        orm.TextBlock.objects.create(category="parentsview", slug="vrolijkste-online-typecursus",
                                     title="De vrolijkste online typecursus",
                                     text="In de cursus werkt uw kind mee als verslaggever van de Duckstadkrant. De oefeningen zijn gecombineerd met spellen, waardoor de typecursus tot het einde leuk blijft.")
        orm.TextBlock.objects.create(category="parentsview", slug="lesmethode-online",
                                     title="Lesmethode online typecursus DuckTypen",
                                     text="")
        orm.TextBlock.objects.create(category="parentsview", slug="opbouw-van-de-cursus",
                                     title="Opbouw van de cursus",
                                     text="De opdrachten in de cursus volgen een bestaande lesmethode met verschillende oefeningen: van losse toetsen tot meerdere rijen, tot opdrachten waarbij het hele toetsenbord wordt gebruikt.")
        orm.TextBlock.objects.create(category="parentsview", slug="tijdsduur",
                                     title="Tijdsduur",
                                     text="De online typecursus bestaat uit 30 lesuren die verdeeld zijn over zes kranten: vijf uur les per krant. Aangeraden wordt de cursus vijf keer in de week te spelen, ongeveer 30 minuten per dag. Bij een gemiddeld niveau kan de cursus in 12 weken worden afgerond. De licentie is een jaar geldig.")
        orm.TextBlock.objects.create(category="parentsview", slug="duckse-duiten",
                                     title="Duckse Duiten",
                                     text="Aan het begin van de cursus stelt uw kind een persoonlijke avatar samen. Na elk spel of elke oefening kunnen er Duckse Duiten worden verdiend. Hiermee kan uw kind in het warenhuis van Duckstad kleding en accessoires kopen voor zijn of haar avatar. Hoe meer sterren uw kind haalt na een leeroefening, hoe meer Duckse Duiten er worden verdiend.")
        orm.TextBlock.objects.create(category="parentsview", slug="diploma",
                                     title="Diploma",
                                     text="De cursist is geslaagd als de laatste krant af is. Hij of zij ontvangt een online diploma, ondertekend door oom Donald. Zowel het diploma als de eerder geschreven artikelen en kranten kunnen worden afgedrukt.")
        orm.TextBlock.objects.create(category="parentsview", slug="motivatie-en-begeleiding",
                                     title="Motivatie en begeleiding",
                                     text="")
        orm.TextBlock.objects.create(category="parentsview", slug="begeleiding",
                                     title="Begeleiding",
                                     text="Tijdens de cursus wordt uw kind begeleid door een mentor: meester Warbol. Hij geeft uitleg aan het begin van elk level en motiveert uw zoon of dochter met positief en stimulerend commentaar.")
        orm.TextBlock.objects.create(category="parentsview", slug="dashboard",
                                     title="Dashboard",
                                     text="Als ouder kunt u de voortgang van uw kind volgen. In het speciale ouderdashboard ziet u waar uw kind zich in de cursus bevindt, welke scores hij of zij heeft behaald en met hoeveel aanslagen per minuut uw kind al kan typen. Vanuit dit dashboard kunt u ook motiverende berichtjes naar uw zoon of dochter sturen.")
        orm.TextBlock.objects.create(category="parentsview", slug="motivatie",
                                     title="Motivatie",
                                     text="Een cursus volhouden is soms moeilijk voor kinderen. Daarom doet Ducktypen er alles aan de online typecursus zo leuk mogelijk te houden. Zo kan uw kind zelf een avatar samenstellen waarmee hij of zij gaat spelen. Daarnaast verdient uw zoon of dochter Duckse Duiten voor extra spulletjes voor zijn of haar avatar. Er vallen extra Duiten te verdienen door drie keer per week in te loggen of spellen vaker te spelen.")
        orm.TextBlock.objects.create(category="parentsview", slug="parents-opinion",
                                     title="Annemieke Bitterling",
                                     text='“DuckTypen vinden wij goed. Onze dochter heeft telkens zin om aan de cursus te beginnen en wij zien haar vorderingen duidelijk.”')
        orm.TextBlock.objects.create(category="parentsview", slug="waarom-blind-typen",
                                     title="Waarom blind typen",
                                     text="")
        orm.TextBlock.objects.create(category="parentsview", slug="snelheid",
                                     title="Snelheid",
                                     text="Blind typen helpt uw kind op weg in de 21e eeuw. In deze tijd zijn computers niet meer weg te denken en is blind en snel typen een belangrijke vaardigheid. Het scheelt simpelweg tijd.")
        orm.TextBlock.objects.create(category="parentsview", slug="efficientie",
                                     title="Efficiëntie",
                                     text="Wanneer je typt zonder telkens naar het toetsenbord te hoeven kijken, is je werk sneller af. De focus ligt immers op de inhoud, niet op het toetsenbord. Dit zorgt voor een hogere concentratie, waardoor uw kind meer kan doen in minder tijd, zonder te worden afgeleid door het toetsenbord.")
        orm.TextBlock.objects.create(category="parentsview", slug="goede-lichaamshouding",
                                     title="Goede lichaamshouding",
                                     text="Blind typen zorgt voor een goede lichaamshouding. Uw zoon of dochter hoeft niet meer voorover gebogen te zitten, op zoek naar de juiste toetsen. Daarnaast gebruikt hij of zij tien vingers, waardoor de kans op RSI afneemt.")
        orm.TextBlock.objects.create(category="parentsview", slug="duckwise",
                                     title="DuckWise",
                                     text="")
        orm.TextBlock.objects.create(category="parentsview", slug="educatie-fun",
                                     title="Educatie & Fun",
                                     text="Ducktypen is een product van het edutainment label DuckWise. DuckWise is opgericht door de makers van Donald Duck Weekblad, Sanoma Learning (Malmberg) en The Walt Disney Company. DuckWise ontwikkelt (digitale) leeroplossingen waarin educatie en fun samen komen. De focus ligt op 21st Century skills, benodigde vaardigheden om succesvol te zijn in de 21e eeuw. Meer weten? Bezoek dan de DuckWise website.")
        orm.TextBlock.objects.create(category="parentsview", slug="bestel-hier-de-cursus",
                                     title="Educatie en Fun. Bestel hier de cursus",
                                     text="In de cursus werkt je kind mee als verslaggever van de Duckstadkrant. Games gecombineerd met leeroefeningen zorgen dat de typecursus tot het einde leuk blijft.")
        orm.TextBlock.objects.create(category="parentsview", slug="korting",
                                     title="Ontvang 20% korting op een 2e cursus!",
                                     text="Bestelt u twee cursussen, dan ontvangt u altijd 20% korting op de 2e typecursus.")
        # SchoolsView
        orm.TextBlock.objects.create(category="schoolsview", slug="main-header",
                                     title="De online typecursus waar kinderen zelf voor gaan zitten",
                                     text="Nu ook beschikbaar voor scholen!")
        orm.TextBlock.objects.create(category="schoolsview", slug="tab1-header",
                                     title="DuckTypen op school",
                                     text="")
        orm.TextBlock.objects.create(category="schoolsview", slug="tab1-op-de-cursus",
                                     title="Over de cursus",
                                     text="Voor schoolopdrachten en de toekomst van leerlingen is een goede typevaardigheid haast onmisbaar. Daarom is het ook mogelijk voor scholen om Ducktypen te bestellen. De opdrachten in de cursus volgen een bestaande lesmethode met verschillende oefeningen: van losse toetsen tot meerdere rijen, tot opdrachten waarbij het hele toetsenbord wordt gebruikt. De verschillende oefeningen zijn gecombineerd met spellen, waardoor de typecursus tot het einde leuk blijft.")
        orm.TextBlock.objects.create(category="schoolsview", slug="tab1-tijdsduur",
                                     title="Tijdsduur",
                                     text="De online typecursus bestaat uit 30 lesuren die verdeeld zijn over zes kranten: vijf uur les per krant. De typecursus is geheel online, dus kinderen kunnen naast oefeningen in de klas opdrachten meekrijgen voor thuis. Uiteraard kunt u de voortgang van de leerlingen bijhouden via het speciale dashboard voor leerkrachten. De totale cursus beslaat een jaar.")
        orm.TextBlock.objects.create(category="schoolsview", slug="tab1-advies-op-maat",
                                     title="Advies op maat",
                                     text="Voor scholen gelden voordelige tarieven. Bij 10 kinderen of meer geeft DuckTypen advies op maat over een optimale inpassing in uw lesprogramma. Interesse? Vraag dan een offerte aan. Er wordt zo snel mogelijk contact met u opgenomen.")
        orm.TextBlock.objects.create(category="schoolsview", slug="tab1-dashboard",
                                     title="Dashboard",
                                     text="Bij Ducktypen kunt u als leerkracht de voortgang van uw leerlingen in de cursus volgen. Op het speciale dashboard voor leerkrachten ziet u waar uw leerlingen zijn, welke scores zij per level halen en met hoeveel aanslagen per minuut ze al kunnen typen. Ook kunt u vanuit dit dashboard motiverende berichten sturen en de resultaten delen met de ouders van de betreffende leerlingen. ")

        orm.TextBlock.objects.create(category="schoolsview", slug="tab2-header",
                                     title="Waarom blind typen",
                                     text="")
        orm.TextBlock.objects.create(category="schoolsview", slug="tab2-snelheid",
                                     title="Snelheid",
                                     text="Blind typen helpt de leerling op weg in de 21e eeuw. In deze tijd zijn computers niet meer weg te denken en is blind en snel typen een belangrijke vaardigheid. Het scheelt simpelweg tijd.")
        orm.TextBlock.objects.create(category="schoolsview", slug="tab2-efficientie",
                                     title=u"Efficiëntie",
                                     text=u"Wanneer iemand typt zonder telkens naar het toetsenbord te hoeven kijken, is het werk sneller af. De focus ligt immers op de inhoud, niet op het toetsenbord. Dit zorgt voor een hogere concentratie, waardoor de leerling meer kan doen in minder tijd, zonder te worden afgeleid door het toetsenbord.")
        orm.TextBlock.objects.create(category="schoolsview", slug="tab2-lichaamshouding",
                                     title="Goede lichaamshouding",
                                     text="Blind typen zorgt voor een goede lichaamshouding. De leerling hoeft niet meer voorover gebogen te zitten, op zoek naar de juiste toetsen. Daarnaast gebruikt hij of zij tien vingers, waardoor de kans op RSI afneemt.")

        orm.TextBlock.objects.create(category="schoolsview", slug="opinion",
                                     title="FRANK WESTHOF",
                                     text=r"“Mijn zoon vindt de cursus erg leuk. Hij wordt door de spellen getriggerd om zelf te gaan oefenen. En ondertussen leert hij typen. Een goede aanschaf!”")

        orm.TextBlock.objects.create(category="schoolsview", slug="tab3-header",
                                     title="DuckWise",
                                     text="")
        orm.TextBlock.objects.create(category="schoolsview", slug="tab3-educatie-and-fun",
                                     title="Educatie &amp; fun",
                                     text="Ducktypen is een product van het merk DuckWise. DuckWise is opgericht door de makers van Donald Duck Weekblad, Sanoma Learning (Malmberg) en The Walt Disney Company. DuckWise ontwikkelt (digitale) leeroplossingen waarin educatie en fun samen komen. De focus ligt op de 21st century skills, benodigde vaardigheden die de leerling op weg helpen in de 21e eeuw.")

        orm.TextBlock.objects.create(category="schoolsview", slug="opinion-picture",
                                     title="De online typecursus waar kinderen zelf voor gaan zitten!",
                                     text="In de cursus werken de leerlingen mee als verslaggever van de Duckstadkrant. De oefeningen zijn gecombineerd met spellen, waardoor de typecursus tot het einde leuk blijft.")

        # student-login
        orm.TextBlock.objects.create(category="student-login", slug="inloggen-voor-kinderen",
                                     title="Inloggen voor kinderen",
                                     text="Het is superdruk op de redactie van de Duckstadkrant! Log maar snel in. We hebben je nodig!")
        orm.TextBlock.objects.create(category="student-login", slug="wachtwoord-vergeten",
                                     title="Wachtwoord vergeten?",
                                     text="Vraag je ouders om in te loggen en je wachtwoord aan te passen.")

        # parent-login
        orm.TextBlock.objects.create(category="parent-login", slug="inloggen-voor-ouders",
                                     title="Inloggen voor ouders",
                                     text="U kunt hier inloggen voor Ducktypen. Op het ouderdashboard kunt u de voortgang van uw kind(eren) zien en ze af en toe een berichtje sturen. Via het ouderdashboard kunt u ook het wachtwoord van uw kind wijzigen.")

        # OrderHomeView
        orm.TextBlock.objects.create(category="orderhomeview", slug="bestel-hier-de-online-typecursus",
                                     title="DuckTypen, educatie en fun!",
                                     text="Bestel hier de online typecursus DuckTypen, waarmee kinderen spelenderwijs blind leren typen.")
        orm.TextBlock.objects.create(category="orderhomeview", slug="ducktypen-voor-scholen",
                                     title="DuckTypen voor scholen",
                                     text="Bent u opzoek naar een typecursus om in uw klas of op school aan te bieden? Scholen die meer dan 10 licenties willen bestellen kunnen via de speciale contactpagina een advies en tarief op maat ontvangen.")
        orm.TextBlock.objects.create(category="orderhomeview", slug="order-opinion",
                                     title="FRANK WESTHOF",
                                     text='"Mijn zoon vindt de cursus erg leuk. Hij wordt door de spellen getriggerd om zelf te gaan oefenen. En ondertussen leert hij typen. Een goede aanschaf!"')


    def backwards(self, orm):
        "Write your backwards methods here."

    models = {
        'textblock.textblock': {
            'Meta': {'ordering': "('category',)", 'unique_together': "(('category', 'slug'),)", 'object_name': 'TextBlock'},
            'category': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '80'}),
            'text': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'})
        }
    }

    complete_apps = ['textblock']
    symmetrical = True
