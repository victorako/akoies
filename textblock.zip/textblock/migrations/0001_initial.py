# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'TextBlock'
        db.create_table('textblock_textblock', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('category', self.gf('django.db.models.fields.CharField')(max_length=80)),
            ('slug', self.gf('django.db.models.fields.SlugField')(max_length=80)),
            ('title', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('text', self.gf('django.db.models.fields.TextField')()),
        ))
        db.send_create_signal('textblock', ['TextBlock'])

        # Adding unique constraint on 'TextBlock', fields ['category', 'slug']
        db.create_unique('textblock_textblock', ['category', 'slug'])


    def backwards(self, orm):
        # Removing unique constraint on 'TextBlock', fields ['category', 'slug']
        db.delete_unique('textblock_textblock', ['category', 'slug'])

        # Deleting model 'TextBlock'
        db.delete_table('textblock_textblock')


    models = {
        'textblock.textblock': {
            'Meta': {'unique_together': "(('category', 'slug'),)", 'object_name': 'TextBlock'},
            'category': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '80'}),
            'text': ('django.db.models.fields.TextField', [], {}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        }
    }

    complete_apps = ['textblock']