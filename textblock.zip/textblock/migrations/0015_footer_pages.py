# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import DataMigration
from django.db import models

class Migration(DataMigration):

    def forwards(self, orm):
        
        #typing lessons
        orm.TextBlock.objects.create(category="typinglessonsview", slug="vrolijkste-online-typecursus",
                                     title="header title",
                                     text="header text")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="lesmethode-online",
                                     title="header tab 1",
                                     text="")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="opbouw-van-de-cursus",
                                     title="tab 1 item 1",
                                     text="tab 1 item 1")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="tijdsduur",
                                     title="tab 1 item 2",
                                     text="tab 1 item 2")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="duckse-duiten",
                                     title="tab 1 item 3",
                                     text="tab 1 item 3")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="diploma",
                                     title="tab 1 item 4",
                                     text="tab 1 item 4")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="motivatie-en-begeleiding",
                                     title="tab 2 header",
                                     text="")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="begeleiding",
                                     title="tab 2 item 1",
                                     text="tab 2 item 1")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="dashboard",
                                     title="tab 2 item 2",
                                     text="tab 2 item 2")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="motivatie",
                                     title="tab 2 item 3",
                                     text="tab 2 item 3")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="parents-opinion",
                                     title="opinion",
                                     text='opinion')
        orm.TextBlock.objects.create(category="typinglessonsview", slug="waarom-blind-typen",
                                     title="header tab 3",
                                     text="")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="snelheid",
                                     title="tab 3 item 1",
                                     text="tab 3 item 1")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="efficientie",
                                     title="tab 3 item 2",
                                     text="tab 3 item 2")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="goede-lichaamshouding",
                                     title="tab 3 item 3",
                                     text="tab 3 item 3")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="duckwise",
                                     title="tab 4 header",
                                     text="")

        orm.TextBlock.objects.create(category="typinglessonsview", slug="educatie-fun",
                                     title="tab 4 item 1",
                                     text="tab 4 item 1")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="bestel-hier-de-cursus",
                                     title="Opinion picture",
                                     text="Opinion picture")
        orm.TextBlock.objects.create(category="typinglessonsview", slug="korting",
                                     title="Promotion",
                                     text="Promotion")

        orm.TextBlock.objects.create(category="typinglessonsview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")


        #learn blind typing
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="vrolijkste-online-typecursus",
                                     title="header title",
                                     text="header text")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="lesmethode-online",
                                     title="header tab 1",
                                     text="")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="opbouw-van-de-cursus",
                                     title="tab 1 item 1",
                                     text="tab 1 item 1")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="tijdsduur",
                                     title="tab 1 item 2",
                                     text="tab 1 item 2")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="duckse-duiten",
                                     title="tab 1 item 3",
                                     text="tab 1 item 3")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="diploma",
                                     title="tab 1 item 4",
                                     text="tab 1 item 4")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="motivatie-en-begeleiding",
                                     title="tab 2 header",
                                     text="")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="begeleiding",
                                     title="tab 2 item 1",
                                     text="tab 2 item 1")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="dashboard",
                                     title="tab 2 item 2",
                                     text="tab 2 item 2")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="motivatie",
                                     title="tab 2 item 3",
                                     text="tab 2 item 3")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="parents-opinion",
                                     title="opinion",
                                     text='opinion')
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="waarom-blind-typen",
                                     title="header tab 3",
                                     text="")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="snelheid",
                                     title="tab 3 item 1",
                                     text="tab 3 item 1")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="efficientie",
                                     title="tab 3 item 2",
                                     text="tab 3 item 2")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="goede-lichaamshouding",
                                     title="tab 3 item 3",
                                     text="tab 3 item 3")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="duckwise",
                                     title="tab 4 header",
                                     text="")

        orm.TextBlock.objects.create(category="learnblindtypingview", slug="educatie-fun",
                                     title="tab 4 item 1",
                                     text="tab 4 item 1")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="bestel-hier-de-cursus",
                                     title="Opinion picture",
                                     text="Opinion picture")
        orm.TextBlock.objects.create(category="learnblindtypingview", slug="korting",
                                     title="Promotion",
                                     text="Promotion")

        orm.TextBlock.objects.create(category="learnblindtypingview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

        #typing skills
        orm.TextBlock.objects.create(category="typingskillsview", slug="vrolijkste-online-typecursus",
                                     title="header title",
                                     text="header text")
        orm.TextBlock.objects.create(category="typingskillsview", slug="lesmethode-online",
                                     title="header tab 1",
                                     text="")
        orm.TextBlock.objects.create(category="typingskillsview", slug="opbouw-van-de-cursus",
                                     title="tab 1 item 1",
                                     text="tab 1 item 1")
        orm.TextBlock.objects.create(category="typingskillsview", slug="tijdsduur",
                                     title="tab 1 item 2",
                                     text="tab 1 item 2")
        orm.TextBlock.objects.create(category="typingskillsview", slug="duckse-duiten",
                                     title="tab 1 item 3",
                                     text="tab 1 item 3")
        orm.TextBlock.objects.create(category="typingskillsview", slug="diploma",
                                     title="tab 1 item 4",
                                     text="tab 1 item 4")
        orm.TextBlock.objects.create(category="typingskillsview", slug="motivatie-en-begeleiding",
                                     title="tab 2 header",
                                     text="")
        orm.TextBlock.objects.create(category="typingskillsview", slug="begeleiding",
                                     title="tab 2 item 1",
                                     text="tab 2 item 1")
        orm.TextBlock.objects.create(category="typingskillsview", slug="dashboard",
                                     title="tab 2 item 2",
                                     text="tab 2 item 2")
        orm.TextBlock.objects.create(category="typingskillsview", slug="motivatie",
                                     title="tab 2 item 3",
                                     text="tab 2 item 3")
        orm.TextBlock.objects.create(category="typingskillsview", slug="parents-opinion",
                                     title="opinion",
                                     text='opinion')
        orm.TextBlock.objects.create(category="typingskillsview", slug="waarom-blind-typen",
                                     title="header tab 3",
                                     text="")
        orm.TextBlock.objects.create(category="typingskillsview", slug="snelheid",
                                     title="tab 3 item 1",
                                     text="tab 3 item 1")
        orm.TextBlock.objects.create(category="typingskillsview", slug="efficientie",
                                     title="tab 3 item 2",
                                     text="tab 3 item 2")
        orm.TextBlock.objects.create(category="typingskillsview", slug="goede-lichaamshouding",
                                     title="tab 3 item 3",
                                     text="tab 3 item 3")
        orm.TextBlock.objects.create(category="typingskillsview", slug="duckwise",
                                     title="tab 4 header",
                                     text="")

        orm.TextBlock.objects.create(category="typingskillsview", slug="educatie-fun",
                                     title="tab 4 item 1",
                                     text="tab 4 item 1")
        orm.TextBlock.objects.create(category="typingskillsview", slug="bestel-hier-de-cursus",
                                     title="Opinion picture",
                                     text="Opinion picture")
        orm.TextBlock.objects.create(category="typingskillsview", slug="korting",
                                     title="Promotion",
                                     text="Promotion")

        orm.TextBlock.objects.create(category="typingskillsview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")


    def backwards(self, orm):
        "Write your backwards methods here."

    models = {
        'textblock.textblock': {
            'Meta': {'ordering': "('category',)", 'unique_together': "(('category', 'slug'),)", 'object_name': 'TextBlock'},
            'category': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '80'}),
            'text': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'})
        }
    }

    complete_apps = ['textblock']
    symmetrical = True
