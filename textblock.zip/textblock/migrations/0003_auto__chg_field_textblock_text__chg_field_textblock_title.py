# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):

        # Changing field 'TextBlock.text'
        db.alter_column('textblock_textblock', 'text', self.gf('django.db.models.fields.TextField')(default=''))

        # Changing field 'TextBlock.title'
        db.alter_column('textblock_textblock', 'title', self.gf('django.db.models.fields.CharField')(default='', max_length=255))

    def backwards(self, orm):

        # Changing field 'TextBlock.text'
        db.alter_column('textblock_textblock', 'text', self.gf('django.db.models.fields.TextField')(null=True))

        # Changing field 'TextBlock.title'
        db.alter_column('textblock_textblock', 'title', self.gf('django.db.models.fields.CharField')(max_length=255, null=True))

    models = {
        'textblock.textblock': {
            'Meta': {'ordering': "('category',)", 'unique_together': "(('category', 'slug'),)", 'object_name': 'TextBlock'},
            'category': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '80'}),
            'text': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'})
        }
    }

    complete_apps = ['textblock']