# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import DataMigration
from django.db import models

class Migration(DataMigration):

    def forwards(self, orm):
        # TicketView
        orm.TextBlock.objects.create(category="contestview", slug="main-header",
                                     title="main-header",
                                     text="main-header")

        orm.TextBlock.objects.create(category="contestview", slug="tab1-header",
                                     title="tab1-header",
                                     text="tab1-header")

        orm.TextBlock.objects.create(category="contestview", slug="tab1-block1",
                                     title="tab1-block1",
                                     text="tab1-block1")

        orm.TextBlock.objects.create(category="contestview", slug="tab1-block2",
                                     title="tab1-block2",
                                     text="tab1-block2")

        orm.TextBlock.objects.create(category="contestview", slug="tab1-block3",
                                     title="tab1-block3",
                                     text="tab1-block3")

        orm.TextBlock.objects.create(category="contestview", slug="tab1-block4",
                                     title="tab1-block4",
                                     text="tab1-block4")

        orm.TextBlock.objects.create(category="contestview", slug="opinion",
                                     title="opinion",
                                     text="opinion")

        orm.TextBlock.objects.create(category="contestview", slug="opinion-picture",
                                     title="opinion-picture",
                                     text="opinion-picture")

    def backwards(self, orm):
        "Write your backwards methods here."

    models = {
        'textblock.textblock': {
            'Meta': {'ordering': "('category',)", 'unique_together': "(('category', 'slug'),)", 'object_name': 'TextBlock'},
            'category': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '80'}),
            'text': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'})
        }
    }

    complete_apps = ['textblock']
    symmetrical = True
