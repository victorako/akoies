# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import DataMigration
from django.db import models

class Migration(DataMigration):

    def forwards(self, orm):

        
        orm.TextBlock.objects.create(category="kidsplayview", slug="main-header",
                                     title="title header",
                                     text="text header")
        orm.TextBlock.objects.create(category="kidsplayview", slug="tab1-header",
                                     title="tab1 header",
                                     text="")
        orm.TextBlock.objects.create(category="kidsplayview", slug="tab1-op-de-cursus",
                                     title="tab1 item 1",
                                     text="tab1 item 1")
        orm.TextBlock.objects.create(category="kidsplayview", slug="tab1-tijdsduur",
                                     title="tab1 item 2",
                                     text="tab1 item 2")
        orm.TextBlock.objects.create(category="kidsplayview", slug="tab1-advies-op-maat",
                                     title="tab1 item 3",
                                     text="tab1 item 3")
        orm.TextBlock.objects.create(category="kidsplayview", slug="tab1-dashboard",
                                     title="tab1 item 4",
                                     text="tab1 item 4")

        orm.TextBlock.objects.create(category="kidsplayview", slug="tab2-header",
                                     title="tab2 header",
                                     text="")
        orm.TextBlock.objects.create(category="kidsplayview", slug="tab2-snelheid",
                                     title="tab2 item 1",
                                     text="tab2 item 1")
        orm.TextBlock.objects.create(category="kidsplayview", slug="tab2-efficientie",
                                     title=u"tab2 item 2",
                                     text=u"tab2 item 2")
        orm.TextBlock.objects.create(category="kidsplayview", slug="tab2-lichaamshouding",
                                     title="tab2 item 3",
                                     text="tab2 item 3")

        orm.TextBlock.objects.create(category="kidsplayview", slug="opinion",
                                     title="opinion",
                                     text="opinion")

        orm.TextBlock.objects.create(category="kidsplayview", slug="tab3-header",
                                     title="tab3 header",
                                     text="")
        orm.TextBlock.objects.create(category="kidsplayview", slug="tab3-educatie-and-fun",
                                     title="tab3 item 1",
                                     text="tab3 item 1")

        orm.TextBlock.objects.create(category="kidsplayview", slug="opinion-picture",
                                     title="opinion picture",
                                     text="opinion picture")

        orm.TextBlock.objects.create(category="kidsplayview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

    def backwards(self, orm):
        "Write your backwards methods here."

    models = {
        'textblock.textblock': {
            'Meta': {'ordering': "('category',)", 'unique_together': "(('category', 'slug'),)", 'object_name': 'TextBlock'},
            'category': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '80'}),
            'text': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'})
        }
    }

    complete_apps = ['textblock']
    symmetrical = True
