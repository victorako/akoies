# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import DataMigration
from django.db import models

class Migration(DataMigration):

    def forwards(self, orm):
        
        orm.TextBlock.objects.create(category="upgradelandingview", slug="meta-tags",
                                     title="Ducktypen",
                                     text="")

    def backwards(self, orm):
        "Write your backwards methods here."

    models = {
        'textblock.textblock': {
            'Meta': {'ordering': "('category',)", 'unique_together': "(('category', 'slug'),)", 'object_name': 'TextBlock'},
            'category': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '80'}),
            'text': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'})
        }
    }

    complete_apps = ['textblock']
    symmetrical = True
