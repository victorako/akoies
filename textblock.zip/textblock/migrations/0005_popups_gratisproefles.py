# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import DataMigration
from django.db import models

class Migration(DataMigration):

    def forwards(self, orm):
        # parent-login
        orm.TextBlock.objects.create(category="parent-login", slug="problemen-met-inloggen",
                                     title="Problemen met inloggen?",
                                     text="Vul uw e-mailadres in en u ontvangt een nieuw wachtwoord.")

        # OrderHomeView
        orm.TextBlock.objects.create(category="orderhomeview", slug="proefles",
                                     title="Proefles",
                                     text="Speel een gratis proefles en zie hoe de cursus is opgebouwd.")
        orm.TextBlock.objects.create(category="orderhomeview", slug="proefles-meer",
                                     title="Proefles",
                                     text="Speel de proefles om te zien hoe de DuckTypen typecursus is opgebouwd. De proefles is gratis.")
        orm.TextBlock.objects.create(category="orderhomeview", slug="premium",
                                     title="Premium",
                                     text="Koop DuckTypen Premium en krijg een cursus voor een kind. Hij/ zij kan een jaar spelen.")
        orm.TextBlock.objects.create(category="orderhomeview", slug="premium-meer",
                                     title="Lees Meer Premium",
                                     text="Meer informatie over het Premium pakket")
        orm.TextBlock.objects.create(category="orderhomeview", slug="family",
                                     title="Family",
                                     text="Koop DuckTypen Family en krijg 2 cursussen! Beide kinderen kunnen een jaar spelen.")
        orm.TextBlock.objects.create(category="orderhomeview", slug="family-meer",
                                     title="Lees Meer Family",
                                     text="Meer informatie over het Family pakket")

        # avatar_select_new
        orm.TextBlock.objects.create(category="page-trial", slug="ducktypen-spelen",
                                     title="DuckTypen spelen",
                                     text="Selecteer je avatar, waar je de proefles mee wilt spelen")
        orm.TextBlock.objects.create(category="page-trial", slug="bestel-de-volledige-cursus",
                                     title="Bestel de volledige cursus",
                                     text="Bestel hier de online typecursus DuckTypen, waarmee kinderen spelenderwijs blind leren typen.")
        orm.TextBlock.objects.create(category="page-trial", slug="premium",
                                     title="Premium",
                                     text="Koop DuckTypen Premium en krijg een typecursus. Uw kind kan een jaar lang spelen.")
        orm.TextBlock.objects.create(category="page-trial", slug="premium-meer",
                                     title="Lees Meer Premium",
                                     text="Meer informatie over het Premium pakket")
        orm.TextBlock.objects.create(category="page-trial", slug="family",
                                     title="Family",
                                     text="Koop DuckTypen Family en krijg 2 cursussen! Beide kinderen kunnen een jaar spelen.")
        orm.TextBlock.objects.create(category="page-trial", slug="family-meer",
                                     title="Lees Meer Family",
                                     text="Meer informatie over het Family pakket")


    def backwards(self, orm):
        "Write your backwards methods here."

    models = {
        'textblock.textblock': {
            'Meta': {'ordering': "('category',)", 'unique_together': "(('category', 'slug'),)", 'object_name': 'TextBlock'},
            'category': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '80'}),
            'text': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'})
        }
    }

    complete_apps = ['textblock']
    symmetrical = True
