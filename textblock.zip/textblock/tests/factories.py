from django.template.defaultfilters import slugify
from apps.textblock import models

import factory


class TextBlockFactory(factory.django.DjangoModelFactory):
    FACTORY_FOR = models.TextBlock

    title = factory.Sequence(lambda n: 'TextBlock {0}'.format(n))
    slug = factory.LazyAttribute(lambda obj: slugify(obj.title))
