# -*- coding: utf-8 -*-
from django.test import TestCase

import apps.textblock.tests.factories as facs


class TextBlockTest(TestCase):

    def test_unicode(self):
        """
        Test if unicode is equal to title
        """
        text_block1 = facs.TextBlockFactory()
        self.assertEqual(text_block1.__unicode__(), text_block1.title, 'unicode should be equal to title')
